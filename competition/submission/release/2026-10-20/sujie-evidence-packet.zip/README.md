# 证据包说明（脱敏）

- 生成时间（UTC）：2026-10-21T02:20:51+00:00
- 生成方式：`competition/submission/tools/build_evidence_packet.py`
- 口径限定：**离线档案一致性核验**，不代表签名真实性、实验全成功或攻击成功率（ASR）。
- 排除内容：云凭据、本地预算账本（`*.sqlite3`）、个人环境与缓存。

## 复现命令

```sh
cd sujie
# 1) 四业务确定性运行（现场生成新目录）并核验
.venv/bin/python eval/run_business_validation.py \
  --protocol-file eval/protocols/four_business_workflows_v2.json \
  --out-dir eval/reports/runs/<新目录>
.venv/bin/python eval/verify_runtime_validation.py eval/reports/runs/<新目录>
# 2) 离线检测评测（规则初筛，非 Agent ASR）
.venv/bin/python dev.py eval-detection
.venv/bin/python dev.py eval-bypass
.venv/bin/python eval/run_public_injection.py
# 3) 溯源图演示（离线）
.venv/bin/python eval/provenance_demo.py --out <新目录>
```

## 目录

- `runs/<dir>/summary.json`：总体结果与源码归档 SHA-256。
- `runs/<dir>/*-report.txt`：各用例业务报告。
- `runs/<dir>/*-export.json`：各用例运行导出（来源与工具轨迹）。
- `runs/<dir>/runtime-sources.json`：运行时源码快照索引。
- `runs/validation/*.json`：项目验证记录（M25/M26 本地验收、主线能力审计）。
